document.getElementById("foot01").innerHTML =
"<p>&copy;  " + new Date().getFullYear() + " . All rights reserved.</p>";

document.getElementById("nav01").innerHTML =
"<ul id='menu'>" +
"<li><a href='index.html'>Home</a></li>" +
"<li><a href='customers.html'>Data</a></li>" +
"<li><a href='about.html'>About</a></li>" +
"<li><a href='services.html'>Services</a></li>" +
"<li><a href='Meet.html'>Meet our Team</a></li>" +
"<li><a href='contact.html'>Contact/Join us</a></li>" +
"</ul>";